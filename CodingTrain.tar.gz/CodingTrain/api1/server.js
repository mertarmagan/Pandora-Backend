// Initial users object in the server
var users = {}

console.log("Server is starting..");

var express = require("express");
var bodyParser = require("body-parser");
var fs = require("fs");

var app = express();

var PORT = 3000;
var server = app.listen(PORT, listening);

var userID = 0;

function listening() {
	console.log("listening on port: "+ PORT);
}

app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('/users', sendAllUsers);
function sendAllUsers(req, res) {
	res.send(users);
}

app.get('/search/:user', searchUser);
function searchUser(req, res) {
	var username = req.params.user;
	var reply;
	if(users[username]){
		reply = {
			status: "found",
			user: username,
			id: users[username]
		}
	} else {
		reply = {
			status: "not found",
			user: username
		}
	}

	res.send(reply);
}

app.get('/add/:username/:id?', addUser);
function addUser(req, res) {
	var data = req.params;
	var username = data.username;
	var id = Number(data.id);
	var reply;

	if(!id){
		reply = {
			msg: "id is required."
		}
	} else {
		users[username] = id;
		reply = {
			msg: "User added."
		}
	}
	res.send(reply);
}

app.post('/', adminLogin);
function adminLogin(req, res) {
	var inputPass = req.body.pass;
	var inputName = req.body.username;

	var data = fs.readFileSync("./admin/pass.json");
	var passObject = JSON.parse(data);
	var storedPass = passObject.password;
	var reply;

	// Checking whether the username exists!
	var exist = checkUsername(inputName);

	if(!exist && inputPass === storedPass){
		userID++;
		users[inputName] = userID;
		reply = {
			success: "true"
		}
	}	else {
		reply = {
			success: "false"
		}
	}
	//console.log(inputPass + " - " + storedPass);
	res.send(reply);
}

function guestLogin(req, res){
}

function checkUsername(username){
	//var length = Object.keys(users).length;
	if(users[username])
		return true;
	else
		return false;
}
